- Esp32_radio_init.ino is a tool to set preferences like WiFi networks to the ESP32.
- prefbug.ino          is a tool to test the NVS library.

